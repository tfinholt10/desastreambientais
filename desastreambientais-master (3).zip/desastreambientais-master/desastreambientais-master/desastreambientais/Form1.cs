﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace desastreambientais
{
    public partial class Form1 : Form
    {
        private DAL _banco = new DAL();
        int contador;

        public Form1()
        {
            InitializeComponent();
            _banco.DBName = "quiz";
            _banco.Conectar();
            contador = 0;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 novaform = new Form2();
            novaform.contador = contador;
            novaform.ShowDialog();
            contador = novaform.contador;

            Form3 novaform3 = new Form3();
            novaform3.contador = contador;
            novaform3.ShowDialog();
            contador = novaform3.contador;

            Form4 novaforma4 = new Form4();
            novaforma4.contador = contador;
            novaforma4.ShowDialog();
            contador = novaforma4.contador;

            Form5 novaform5 = new Form5();
            novaform5.contador = contador;
            novaform5.ShowDialog();
            contador = novaform5.contador;

            Form6 novaform6 = new Form6();
            novaform6.contador = contador;
            novaform6.ShowDialog();

            try
            {
                string sql = "INSERT INTO funcionario ";
                sql += "(id, nome,) VALUES (NULL,'";
                sql += textBox1.Text + "')";

                _banco.Inserir(sql);
                textBox1.Text = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }

}