﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace desastreambientais
{
    public partial class Form2 : Form
    {
        public int contador;
        private DAL _banco = new DAL();

        public Form2()
        {
            InitializeComponent();
            contador = 0;
            _banco.DBName = "quiz";
            _banco.Conectar();


        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                contador = contador + 1;

                try
                {
                    
                    string sql = "UPDATE quiz.funcionario SET resp1 = 1";
                    sql += radioButton1.Text + "')";
                    _banco.Inserir(sql);
                    
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
            if (radioButton1.Checked == false)
            {
                contador = contador + 0;

                try
                {

                    string sql = "UPDATE quiz.funcionario SET resp1 = 0";



                    _banco.Inserir(sql);

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

            Close(); 
        }
    }
}
