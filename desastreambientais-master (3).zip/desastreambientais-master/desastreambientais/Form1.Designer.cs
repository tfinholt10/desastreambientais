﻿namespace desastreambientais
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.rsbtn = new System.Windows.Forms.Button();
            this.pebtn = new System.Windows.Forms.Button();
            this.pbbtn = new System.Windows.Forms.Button();
            this.rnbtn = new System.Windows.Forms.Button();
            this.cebtn = new System.Windows.Forms.Button();
            this.pibtn = new System.Windows.Forms.Button();
            this.mabtn = new System.Windows.Forms.Button();
            this.apbtn = new System.Windows.Forms.Button();
            this.rrbtn = new System.Windows.Forms.Button();
            this.sebtn = new System.Windows.Forms.Button();
            this.pabtn = new System.Windows.Forms.Button();
            this.ambtn = new System.Windows.Forms.Button();
            this.acbtn = new System.Windows.Forms.Button();
            this.babtn = new System.Windows.Forms.Button();
            this.tobtn = new System.Windows.Forms.Button();
            this.robtn = new System.Windows.Forms.Button();
            this.mtbtn = new System.Windows.Forms.Button();
            this.gobtn = new System.Windows.Forms.Button();
            this.msbtn = new System.Windows.Forms.Button();
            this.esbtn = new System.Windows.Forms.Button();
            this.rjbtn = new System.Windows.Forms.Button();
            this.mgbtn = new System.Windows.Forms.Button();
            this.spbtn = new System.Windows.Forms.Button();
            this.prbtn = new System.Windows.Forms.Button();
            this.scbtn = new System.Windows.Forms.Button();
            this.albtn = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // rsbtn
            // 
            this.rsbtn.Location = new System.Drawing.Point(444, 599);
            this.rsbtn.Name = "rsbtn";
            this.rsbtn.Size = new System.Drawing.Size(40, 23);
            this.rsbtn.TabIndex = 0;
            this.rsbtn.Text = "RS";
            this.rsbtn.UseVisualStyleBackColor = true;
            // 
            // pebtn
            // 
            this.pebtn.Location = new System.Drawing.Point(726, 258);
            this.pebtn.Name = "pebtn";
            this.pebtn.Size = new System.Drawing.Size(31, 23);
            this.pebtn.TabIndex = 1;
            this.pebtn.Text = "PE";
            this.pebtn.UseVisualStyleBackColor = true;
            // 
            // pbbtn
            // 
            this.pbbtn.Location = new System.Drawing.Point(723, 229);
            this.pbbtn.Name = "pbbtn";
            this.pbbtn.Size = new System.Drawing.Size(34, 23);
            this.pbbtn.TabIndex = 2;
            this.pbbtn.Text = "PB";
            this.pbbtn.UseVisualStyleBackColor = true;
            // 
            // rnbtn
            // 
            this.rnbtn.Location = new System.Drawing.Point(701, 209);
            this.rnbtn.Name = "rnbtn";
            this.rnbtn.Size = new System.Drawing.Size(32, 23);
            this.rnbtn.TabIndex = 3;
            this.rnbtn.Text = "RN";
            this.rnbtn.UseVisualStyleBackColor = true;
            // 
            // cebtn
            // 
            this.cebtn.Location = new System.Drawing.Point(647, 198);
            this.cebtn.Name = "cebtn";
            this.cebtn.Size = new System.Drawing.Size(34, 23);
            this.cebtn.TabIndex = 4;
            this.cebtn.Text = "CE";
            this.cebtn.UseVisualStyleBackColor = true;
            // 
            // pibtn
            // 
            this.pibtn.Location = new System.Drawing.Point(595, 241);
            this.pibtn.Name = "pibtn";
            this.pibtn.Size = new System.Drawing.Size(32, 23);
            this.pibtn.TabIndex = 5;
            this.pibtn.Text = "PI";
            this.pibtn.UseVisualStyleBackColor = true;
            // 
            // mabtn
            // 
            this.mabtn.Location = new System.Drawing.Point(566, 186);
            this.mabtn.Name = "mabtn";
            this.mabtn.Size = new System.Drawing.Size(37, 23);
            this.mabtn.TabIndex = 6;
            this.mabtn.Text = "MA";
            this.mabtn.UseVisualStyleBackColor = true;
            // 
            // apbtn
            // 
            this.apbtn.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.apbtn.Location = new System.Drawing.Point(444, 94);
            this.apbtn.Name = "apbtn";
            this.apbtn.Size = new System.Drawing.Size(40, 23);
            this.apbtn.TabIndex = 7;
            this.apbtn.Text = "AP";
            this.apbtn.UseVisualStyleBackColor = false;
            // 
            // rrbtn
            // 
            this.rrbtn.Location = new System.Drawing.Point(301, 85);
            this.rrbtn.Name = "rrbtn";
            this.rrbtn.Size = new System.Drawing.Size(40, 23);
            this.rrbtn.TabIndex = 8;
            this.rrbtn.Text = "RR";
            this.rrbtn.UseVisualStyleBackColor = true;
            // 
            // sebtn
            // 
            this.sebtn.Location = new System.Drawing.Point(689, 303);
            this.sebtn.Name = "sebtn";
            this.sebtn.Size = new System.Drawing.Size(34, 24);
            this.sebtn.TabIndex = 9;
            this.sebtn.Text = "SE";
            this.sebtn.UseVisualStyleBackColor = true;
            // 
            // pabtn
            // 
            this.pabtn.BackColor = System.Drawing.Color.Cornsilk;
            this.pabtn.Location = new System.Drawing.Point(434, 186);
            this.pabtn.Name = "pabtn";
            this.pabtn.Size = new System.Drawing.Size(40, 23);
            this.pabtn.TabIndex = 10;
            this.pabtn.Text = "PA";
            this.pabtn.UseVisualStyleBackColor = false;
            // 
            // ambtn
            // 
            this.ambtn.Location = new System.Drawing.Point(257, 186);
            this.ambtn.Name = "ambtn";
            this.ambtn.Size = new System.Drawing.Size(38, 23);
            this.ambtn.TabIndex = 11;
            this.ambtn.Text = "AM";
            this.ambtn.UseVisualStyleBackColor = true;
            // 
            // acbtn
            // 
            this.acbtn.Location = new System.Drawing.Point(178, 278);
            this.acbtn.Name = "acbtn";
            this.acbtn.Size = new System.Drawing.Size(33, 23);
            this.acbtn.TabIndex = 12;
            this.acbtn.Text = "AC";
            this.acbtn.UseVisualStyleBackColor = true;
            // 
            // babtn
            // 
            this.babtn.Location = new System.Drawing.Point(636, 321);
            this.babtn.Name = "babtn";
            this.babtn.Size = new System.Drawing.Size(34, 23);
            this.babtn.TabIndex = 13;
            this.babtn.Text = "BA";
            this.babtn.UseVisualStyleBackColor = true;
            // 
            // tobtn
            // 
            this.tobtn.Location = new System.Drawing.Point(512, 288);
            this.tobtn.Name = "tobtn";
            this.tobtn.Size = new System.Drawing.Size(32, 23);
            this.tobtn.TabIndex = 14;
            this.tobtn.Text = "TO";
            this.tobtn.UseVisualStyleBackColor = true;
            // 
            // robtn
            // 
            this.robtn.Location = new System.Drawing.Point(277, 304);
            this.robtn.Name = "robtn";
            this.robtn.Size = new System.Drawing.Size(31, 23);
            this.robtn.TabIndex = 15;
            this.robtn.Text = "RO";
            this.robtn.UseVisualStyleBackColor = true;
            // 
            // mtbtn
            // 
            this.mtbtn.Location = new System.Drawing.Point(387, 335);
            this.mtbtn.Name = "mtbtn";
            this.mtbtn.Size = new System.Drawing.Size(31, 23);
            this.mtbtn.TabIndex = 16;
            this.mtbtn.Text = "MT";
            this.mtbtn.UseVisualStyleBackColor = true;
            // 
            // gobtn
            // 
            this.gobtn.Location = new System.Drawing.Point(488, 385);
            this.gobtn.Name = "gobtn";
            this.gobtn.Size = new System.Drawing.Size(31, 23);
            this.gobtn.TabIndex = 17;
            this.gobtn.Text = "GO";
            this.gobtn.UseVisualStyleBackColor = true;
            // 
            // msbtn
            // 
            this.msbtn.Location = new System.Drawing.Point(409, 445);
            this.msbtn.Name = "msbtn";
            this.msbtn.Size = new System.Drawing.Size(42, 23);
            this.msbtn.TabIndex = 18;
            this.msbtn.Text = "MS";
            this.msbtn.UseVisualStyleBackColor = true;
            // 
            // esbtn
            // 
            this.esbtn.Location = new System.Drawing.Point(636, 445);
            this.esbtn.Name = "esbtn";
            this.esbtn.Size = new System.Drawing.Size(34, 23);
            this.esbtn.TabIndex = 19;
            this.esbtn.Text = "ES";
            this.esbtn.UseVisualStyleBackColor = true;
            // 
            // rjbtn
            // 
            this.rjbtn.Location = new System.Drawing.Point(609, 483);
            this.rjbtn.Name = "rjbtn";
            this.rjbtn.Size = new System.Drawing.Size(45, 24);
            this.rjbtn.TabIndex = 20;
            this.rjbtn.Text = "RJ";
            this.rjbtn.UseVisualStyleBackColor = true;
            // 
            // mgbtn
            // 
            this.mgbtn.Location = new System.Drawing.Point(585, 424);
            this.mgbtn.Name = "mgbtn";
            this.mgbtn.Size = new System.Drawing.Size(34, 23);
            this.mgbtn.TabIndex = 21;
            this.mgbtn.Text = "MG";
            this.mgbtn.UseVisualStyleBackColor = true;
            // 
            // spbtn
            // 
            this.spbtn.Location = new System.Drawing.Point(512, 472);
            this.spbtn.Name = "spbtn";
            this.spbtn.Size = new System.Drawing.Size(32, 23);
            this.spbtn.TabIndex = 22;
            this.spbtn.Text = "SP";
            this.spbtn.UseVisualStyleBackColor = true;
            // 
            // prbtn
            // 
            this.prbtn.Location = new System.Drawing.Point(469, 518);
            this.prbtn.Name = "prbtn";
            this.prbtn.Size = new System.Drawing.Size(40, 23);
            this.prbtn.TabIndex = 23;
            this.prbtn.Text = "PR";
            this.prbtn.UseVisualStyleBackColor = true;
            // 
            // scbtn
            // 
            this.scbtn.Location = new System.Drawing.Point(488, 560);
            this.scbtn.Name = "scbtn";
            this.scbtn.Size = new System.Drawing.Size(31, 19);
            this.scbtn.TabIndex = 24;
            this.scbtn.Text = "SC";
            this.scbtn.UseVisualStyleBackColor = true;
            // 
            // albtn
            // 
            this.albtn.Location = new System.Drawing.Point(714, 287);
            this.albtn.Name = "albtn";
            this.albtn.Size = new System.Drawing.Size(34, 24);
            this.albtn.TabIndex = 25;
            this.albtn.Text = "AL";
            this.albtn.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(95, -41);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(750, 798);
            this.pictureBox1.TabIndex = 26;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(984, 780);
            this.Controls.Add(this.albtn);
            this.Controls.Add(this.scbtn);
            this.Controls.Add(this.prbtn);
            this.Controls.Add(this.spbtn);
            this.Controls.Add(this.mgbtn);
            this.Controls.Add(this.rjbtn);
            this.Controls.Add(this.esbtn);
            this.Controls.Add(this.msbtn);
            this.Controls.Add(this.gobtn);
            this.Controls.Add(this.mtbtn);
            this.Controls.Add(this.robtn);
            this.Controls.Add(this.tobtn);
            this.Controls.Add(this.babtn);
            this.Controls.Add(this.acbtn);
            this.Controls.Add(this.ambtn);
            this.Controls.Add(this.pabtn);
            this.Controls.Add(this.sebtn);
            this.Controls.Add(this.rrbtn);
            this.Controls.Add(this.apbtn);
            this.Controls.Add(this.mabtn);
            this.Controls.Add(this.pibtn);
            this.Controls.Add(this.cebtn);
            this.Controls.Add(this.rnbtn);
            this.Controls.Add(this.pbbtn);
            this.Controls.Add(this.pebtn);
            this.Controls.Add(this.rsbtn);
            this.Controls.Add(this.pictureBox1);
            this.DoubleBuffered = true;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button rsbtn;
        private System.Windows.Forms.Button pebtn;
        private System.Windows.Forms.Button pbbtn;
        private System.Windows.Forms.Button rnbtn;
        private System.Windows.Forms.Button cebtn;
        private System.Windows.Forms.Button pibtn;
        private System.Windows.Forms.Button mabtn;
        private System.Windows.Forms.Button apbtn;
        private System.Windows.Forms.Button rrbtn;
        private System.Windows.Forms.Button sebtn;
        private System.Windows.Forms.Button pabtn;
        private System.Windows.Forms.Button ambtn;
        private System.Windows.Forms.Button acbtn;
        private System.Windows.Forms.Button babtn;
        private System.Windows.Forms.Button tobtn;
        private System.Windows.Forms.Button robtn;
        private System.Windows.Forms.Button mtbtn;
        private System.Windows.Forms.Button gobtn;
        private System.Windows.Forms.Button msbtn;
        private System.Windows.Forms.Button esbtn;
        private System.Windows.Forms.Button rjbtn;
        private System.Windows.Forms.Button mgbtn;
        private System.Windows.Forms.Button spbtn;
        private System.Windows.Forms.Button prbtn;
        private System.Windows.Forms.Button scbtn;
        private System.Windows.Forms.Button albtn;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

