<?php
	
	
	include("conexao.php");
	
	$nome = $_POST["nome"];
	$email = $_POST["email"];
	$senha= $_POST["senha"];
	$senhaconf= $_POST["senhaconf"];
	$cpf=$_POST["cpf"];
    $telefone=$_POST["telefone"];
    $cep= $_POST["cep"];
	
	
	$insert = "INSERT INTO cadastro(nome,email, senha, senhaconf, cpf, telefone,cep)
				VALUES('$nome','$email', '$senha', '$senhaconf', '$cpf', '$telefone', '$cep')";
				
	
	mysqli_query($link, $insert) or die(mysqli_error($link)); 
	echo"<div id='conteudo'>";
	echo "<h3>Cadastro realizado com sucesso.</h3>";
	echo"</div>";

?>