<?php

	$usuario = "root";
	
	$senha = "usbw";
	
	$bd = "desastre";
	
	$servidor = "localhost";
	
	$link = mysqli_connect($servidor, $usuario, $senha, $bd);
	
	

?>