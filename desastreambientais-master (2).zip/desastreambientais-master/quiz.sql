CREATE DATABASE quiz;
USE quiz;

CREATE TABLE quiz.funcionario (
	usuario varchar(15),
    resp1 int,
    resp2 int,
    resp3 int,
    resp4 int);