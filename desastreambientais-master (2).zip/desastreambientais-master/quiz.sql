CREATE DATABASE quiz;
USE quiz;

CREATE TABLE quiz.funcionario (
	id 	int unsigned not null primary key auto_increment,
    nome varchar(20),
    resp1 int,
    resp2 int,
    resp3 int,
    resp4 int,
    respfinal int);
    
    drop table quiz.funcionario;
    
    SELECT * FROM quiz.funcionario;