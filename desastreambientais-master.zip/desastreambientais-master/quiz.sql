DROP DATABASE quiz;
CREATE DATABASE quiz;
USE quiz;

CREATE TABLE quiz.facil (
	id 	int unsigned not null primary key auto_increment,
    nome varchar(20),
    resp1 int,
    resp2 int,
    resp3 int,
    resp4 int,
    respfinal int);
    
    drop table quiz.facil;
    
    SELECT * FROM quiz.facil;
    
    CREATE TABLE quiz.medio (
	id 	int unsigned not null primary key auto_increment,
    nome varchar(20),
    resp1 int,
    resp2 int,
    resp3 int,
    resp4 int,
    respfinal int);
    
    drop table quiz.medio;
    
    SELECT * FROM quiz.medio;
    
    CREATE TABLE quiz.dificil (
	id 	int unsigned not null primary key auto_increment,
    nome varchar(20),
    resp1 int,
    resp2 int,
    resp3 int,
    resp4 int,
    respfinal int);
    
    drop table quiz.dificil;
    
    SELECT * FROM quiz.dificil;
    
    