﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace desastreambientais
{
    public partial class Form16 : Form
    {
        public int contador2;
        private DAL _banco = new DAL();
        private int _quizID;
        public Form16(DAL banco, int quizID)
        {
            InitializeComponent();
            contador2 = 0;
            _banco = banco;
            _quizID = quizID;
        }

        private void Form16_Load(object sender, EventArgs e)
        {
            int respfinal2;
            respfinal2 = contador2;


            try
            {
                string sql = "UPDATE quiz.dificil SET respfinal = @respfinal";
                sql += " where id = @_quizID";

                List<MySqlParameter> valores = new List<MySqlParameter>();
                valores.Add(new MySqlParameter("@respfinal", respfinal2));
                valores.Add(new MySqlParameter("@_quizID", _quizID));
                _banco.Atualizar(sql, valores);



            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            if (contador2 > 1 & contador2 < 4)
            {
                label1.Text = "Parabéns, você acertou " + contador2.ToString() + " perguntas!";
            }

            if (contador2 == 0)
            {
                label1.Text = "Você realmente não tem jeito, errou todas questões! ";
            }

            if (contador2 == 4)
            {
                label1.Text = "Parabéns, você acertou todas as perguntas!";
            }

            if (contador2 == 1)
            {
                label1.Text = "Parabéns, você acertou " + contador2.ToString() + " pergunta!";
            }
        }


        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
