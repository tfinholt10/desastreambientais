﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace desastreambientais
{
    public partial class Form1 : Form
    {
        private DAL _banco = new DAL();
        int contador;
        int contador1;
        int contador2;
        public int quizID;

        public Form1()
        {
            InitializeComponent();
            _banco.DBName = "quiz";
            _banco.Conectar();
            contador = 0;
            contador1 = 0;
            contador2 = 0;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                string sql = "INSERT INTO quiz.facil";
                sql += "(id, nome) VALUES (NULL,'";
                sql += textBox1.Text + "');";
                sql += "SELECT LAST_INSERT_ID() as id;";

                DataSet resultado = _banco.Buscar(sql);




                if (resultado.Tables["tbl_resultado"].Rows.Count == 1)
                {
                    quizID = Convert.ToInt32(resultado.Tables["tbl_resultado"].Rows[0]["id"].ToString());
                    MessageBox.Show(quizID.ToString());

                }
                else
                {
                    MessageBox.Show("Erro!");
                }
            }
            catch (Exception ex)
            {
              
            }




            this.Visible = false;


            Form2 novaform = new Form2(_banco, quizID);
            novaform.contador = contador;
            novaform.ShowDialog();
            contador = novaform.contador;

            Form3 novaform3 = new Form3(_banco, quizID);
            novaform3.contador = contador;
            novaform3.ShowDialog();
            contador = novaform3.contador;

            Form4 novaforma4 = new Form4(_banco, quizID);
            novaforma4.contador = contador;
            novaforma4.ShowDialog();
            contador = novaforma4.contador;

            Form5 novaform5 = new Form5(_banco, quizID);
            novaform5.contador = contador;
            novaform5.ShowDialog();
            contador = novaform5.contador;

            Form6 novaform6 = new Form6(_banco, quizID);
            novaform6.contador = contador;
            novaform6.ShowDialog();

            Close();

           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string sql = "INSERT INTO quiz.medio";
                sql += "(id, nome) VALUES (NULL,'";
                sql += textBox1.Text + "');";
                sql += "SELECT LAST_INSERT_ID() as id;";

                DataSet resultado = _banco.Buscar(sql);




                if (resultado.Tables["tbl_resultado"].Rows.Count == 1)
                {
                    quizID = Convert.ToInt32(resultado.Tables["tbl_resultado"].Rows[0]["id"].ToString());
                    MessageBox.Show(quizID.ToString());

                }
                else
                {
                    MessageBox.Show("Erro!");
                }
            }
            catch (Exception ex)
            {

            }
            
        
            this.Visible = false;


            Form7 novaform7 = new Form7(_banco, quizID);
            novaform7.contador1 = contador1;
            novaform7.ShowDialog();
            contador1 = novaform7.contador1;

            Form8 novaform8 = new Form8(_banco, quizID);
            novaform8.contador1 = contador1;
            novaform8.ShowDialog();
            contador1 = novaform8.contador1;

            Form9 novaforma9 = new Form9(_banco, quizID);
            novaforma9.contador1 = contador1;
            novaforma9.ShowDialog();
            contador1 = novaforma9.contador1;

            Form10 novaform10 = new Form10(_banco, quizID);
            novaform10.contador1 = contador1;
            novaform10.ShowDialog();
            contador1 = novaform10.contador1;

            Form11 novaform11 = new Form11(_banco, quizID);
            novaform11.contador1 = contador1;
            novaform11.ShowDialog();

            Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {


            try
            {
                string sql = "INSERT INTO quiz.dificil";
                sql += "(id, nome) VALUES (NULL,'";
                sql += textBox1.Text + "');";
                sql += "SELECT LAST_INSERT_ID() as id;";

                DataSet resultado = _banco.Buscar(sql);




                if (resultado.Tables["tbl_resultado"].Rows.Count == 1)
                {
                    quizID = Convert.ToInt32(resultado.Tables["tbl_resultado"].Rows[0]["id"].ToString());
                    MessageBox.Show(quizID.ToString());

                }
                else
                {
                    MessageBox.Show("Erro!");
                }
            }
            catch (Exception ex)
            {

            }



            this.Visible = false;


            Form12 novaform12= new Form12(_banco, quizID);
            novaform12.contador2 = contador2;
            novaform12.ShowDialog();
            contador2 = novaform12.contador2;

            Form13 novaform13 = new Form13(_banco, quizID);
            novaform13.contador2 = contador2;
            novaform13.ShowDialog();
            contador2 = novaform13.contador2;

            Form14 novaforma14 = new Form14(_banco, quizID);
            novaforma14.contador2 = contador2;
            novaforma14.ShowDialog();
            contador2 = novaforma14.contador2;

            Form15 novaform15 = new Form15(_banco, quizID);
            novaform15.contador2 = contador2;
            novaform15.ShowDialog();
            contador2 = novaform15.contador2;

            Form16 novaform16 = new Form16(_banco, quizID);
            novaform16.contador2 = contador2;
            novaform16.ShowDialog();

            Close();
        }
    }

}