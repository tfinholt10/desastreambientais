﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace desastreambientais
{
    public partial class Form9 : Form
    {
        public int contador1;
        private DAL _banco = new DAL();
        private int _quizID;
        public Form9(DAL banco, int quizID)
        {

            InitializeComponent();
            contador1 = 0;
            _banco = banco;
            _quizID = quizID;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int resp9;
            if (radioButton3.Checked == true)
            {
                contador1 = contador1 + 1;
                resp9 = 1;

                try
                {
                    string sql = "UPDATE quiz.medio SET resp3 = @resp3";
                    sql += " where id = @_quizID";

                    List<MySqlParameter> valores = new List<MySqlParameter>();
                    valores.Add(new MySqlParameter("@resp3", resp9));
                    valores.Add(new MySqlParameter("@_quizID", _quizID));
                    _banco.Atualizar(sql, valores);



                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

            else
            {
                contador1 = contador1 + 0;
                resp9 = 0;

                try
                {
                    string sql = "UPDATE quiz.medio SET resp3 = @resp3";
                    sql += " where id = @_quizID";

                    List<MySqlParameter> valores = new List<MySqlParameter>();
                    valores.Add(new MySqlParameter("@resp3", resp9));
                    valores.Add(new MySqlParameter("@_quizID", _quizID));
                    _banco.Atualizar(sql, valores);



                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            Close();
        }
    }
}
