﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace desastreambientais
{
    public partial class Form5 : Form
    {
        private DAL _banco = new DAL();
        private int _quizID;
        public int contador;
        public Form5(DAL banco, int quizID)
        {
            InitializeComponent();
            contador = 0;
            _banco = banco;
            _quizID = quizID;
        }




      

        private void button1_Click(object sender, EventArgs e)
        {
            int resp4;

            if (radioButton4.Checked == true)
            {
                contador = contador + 1;

                resp4 = 1;

                try
                {
                    string sql = "UPDATE quiz.facil SET resp4 = @resp4";
                    sql += " where id = @_quizID";

                    List<MySqlParameter> valores = new List<MySqlParameter>();
                    valores.Add(new MySqlParameter("@resp4", resp4));
                    valores.Add(new MySqlParameter("@_quizID", _quizID));
                    _banco.Atualizar(sql, valores);



                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
                if (radioButton4.Checked == false)
                {
                    contador = contador + 0;

                    resp4 = 0;

                    try
                    {
                        string sql = "UPDATE quiz.facil SET resp4 = @resp4 ";
                        sql += " where id = @_quizID";

                        List<MySqlParameter> valores = new List<MySqlParameter>();
                        valores.Add(new MySqlParameter("@resp4", resp4));
                        valores.Add(new MySqlParameter("@_quizID", _quizID));
                        _banco.Atualizar(sql, valores);


                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }





                
            
            Close();
        }
    }
}