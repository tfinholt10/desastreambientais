﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace desastreambientais
{
    public partial class Form7 : Form
    {
        public int contador1;
        private DAL _banco = new DAL();
        private int _quizID;
        public Form7(DAL banco, int quizID)
        {
            InitializeComponent();
            contador1 = 0;
            _banco = banco;
            _quizID = quizID;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int resp7;
            if (radioButton1.Checked == true)
            {
                contador1 = contador1 + 1;

                resp7 = 1;

                try
                {
                    string sql = "UPDATE quiz.medio SET resp1 = @resp1";
                    sql += " where id = @_quizID";

                    List<MySqlParameter> valores = new List<MySqlParameter>();
                    valores.Add(new MySqlParameter("@resp1", resp7));
                    valores.Add(new MySqlParameter("@_quizID", _quizID));
                    _banco.Atualizar(sql, valores);



                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

                
            else
            {
                    contador1 = contador1 + 0;
                    resp7 = 0;

                    try
                    {
                        string sql = "UPDATE quiz.medio SET resp1= @resp1 ";
                        sql += " where id = @_quizID";

                        List<MySqlParameter> valores = new List<MySqlParameter>();
                        valores.Add(new MySqlParameter("@resp1", resp7));
                        valores.Add(new MySqlParameter("@_quizID", _quizID));
                        _banco.Atualizar(sql, valores);


                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
                Close();
            }
        }
    }


