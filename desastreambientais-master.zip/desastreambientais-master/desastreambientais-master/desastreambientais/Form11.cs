﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace desastreambientais
{
    public partial class Form11 : Form
    {
        public int contador1;
        private DAL _banco = new DAL();
        private int _quizID;
        public Form11(DAL banco, int quizID)
        {
            InitializeComponent();
            contador1 = 0;
            _banco = banco;
            _quizID = quizID;
        }

        private void Form11_Load(object sender, EventArgs e)
        {
            int respfinal1;
            respfinal1 = contador1;

            try
            {
                string sql = "UPDATE quiz.medio SET respfinal = @respfinal";
                sql += " where id = @_quizID";

                List<MySqlParameter> valores = new List<MySqlParameter>();
                valores.Add(new MySqlParameter("@respfinal", respfinal1));
                valores.Add(new MySqlParameter("@_quizID", _quizID));
                _banco.Atualizar(sql, valores);



            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            if (contador1 > 1 & contador1 < 4)
            {
                label1.Text = "Parabéns, você acertou " + contador1.ToString() + " perguntas!";
            }

            if (contador1 == 0)
            {
                label1.Text = "Você realmente não tem jeito, errou todas questões! ";
            }

            if (contador1 == 4)
            {
                label1.Text = "Parabéns, você acertou todas as perguntas!";
            }

            if (contador1 == 1)
            {
                label1.Text = "Parabéns, você acertou " + contador1.ToString() + " pergunta!";
            }
        }


        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
